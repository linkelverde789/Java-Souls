package NEGOCIO;

public enum SPECIAL {
    NONE,
    CHEST,
    BATTLE,
    KEY,
    FINAL,
    STAIRS,
    TROPHY

}
