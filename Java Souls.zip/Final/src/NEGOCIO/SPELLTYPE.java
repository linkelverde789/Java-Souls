package NEGOCIO;

public enum SPELLTYPE {
    DAMAGE,
    HEALER
}
